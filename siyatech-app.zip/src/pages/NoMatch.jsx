import React from 'react'

export default function NoMatch() {
  return (
    <div className="text-center pt-5 fs-1">No Page found</div>
  )
}
