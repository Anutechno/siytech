import React from "react";
import "./type.css";

export const TypeEff = () => {
  return (
    <>
      <div class="typing">
        <h2 class="text-uppercase">Creating..</h2>
      </div>
    </>
  );
};
