import React from "react";
import "./header.css";
import Navb from "./Navb";

const Header = () => {
  return (
    <>
      <section>
        <div>
          <Navb />
        </div>
      </section>
    </>
  );
};

export default Header;
