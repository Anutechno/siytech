import "./App.css";
import RootFile from "./rootmodel/RootFile";

function App() {
  return (
    <div className="App">
      <RootFile />
    </div>
  );
}

export default App;
